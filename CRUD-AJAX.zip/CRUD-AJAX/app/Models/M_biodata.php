<?php

namespace App\Models;

use CodeIgniter\Model;

class M_biodata extends Model
{
    protected $table      = 'tb_biodata';
    protected $primaryKey = 'id_biodata';
    protected $allowedFields = ['name', 'address', 'created_at'];
}
