<?= $this->extend('template/ms_template.php') ?>
<?= $this->section('content') ?>

<div class="container">
    <div class="row">
        <div class="col-12">
            <br>
            <H3 class="text-center">DATA BIODATA</H3> <br>

            <a class="btn btn-primary btn-sm" href="<?= base_url('C_biodata/view_create_biodata') ?>">Create</a> <br>

            <table class="table">
                <thead>
                    <tr>
                        <td>No.</td>
                        <td>Name</td>
                        <td>Address</td>
                        <td class="text-center">Created_add</td>
                        <td class="text-center">Action</td>
                    </tr>
                </thead>
                <tbody id="show_data">
                </tbody>
            </table>

        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        my_data();

        function my_data() {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('C_biodata/read_biodata') ?>',
                dataType: 'json',
                success: function(data) {
                    var html = '';
                    var i;
                    for (i = 0, x = 1; i < data.length; i++, x++) {
                        html += '<tr>' +
                            '<td>(' + [x] + ')</td>' +
                            '<td>' + data[i].name + '</td>' +
                            '<td>' + data[i].address + '</td>' +
                            '<td class="text-center">' + data[i].created_at + '</td>' +
                            '<td class="text-center">' +
                            '<a href="<?= base_url('C_biodata/view_update_biodata') ?>/' + data[i].id_biodata + '" class="btn btn-success btn-sm ">Update</a>' + ' ' +
                            '<button type="button" class="btn btn-danger btn-sm" id="delete" data-id="' + data[i].id_biodata + '">Delete</button>' +
                            '</td>' +
                            '</tr>';
                    }
                    $('#show_data').html(html);
                    return false;
                }
            });
        }

        $('#show_data').on('click', '#delete', function() {
            var id = $(this).attr('data-id');
            $.ajax({
                url: "<?= base_url('C_biodata/delete_biodata') ?>",
                type: "POST",
                dataType: 'json',
                data: {
                    id: id,
                },
                success: function(data) {
                    console.log(data);
                    location.href = "<?= base_url('C_biodata') ?>";
                }
            });
        })

    })
</script>

<?= $this->endSection() ?>