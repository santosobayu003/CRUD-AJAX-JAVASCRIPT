<?= $this->extend('template/ms_template.php') ?>
<?= $this->section('content') ?>

<div class="container">
    <div class="row">
        <div class="col-12 col-sm-8">
            <br>
            <h3 class="text-center">CREATE BIODATA</h3> <br>

            <a class="btn btn-primary btn-sm" href="<?= base_url('C_biodata') ?>">Cancel</a> <br><br>

            <form method="post">
                <div class="mb-3">
                    <label class="form-label">Your Name</label>
                    <input type="text" id="name" name="name" class="form-control form-control-sm validation" placeholder="Your Name">
                </div>

                <div class="mb-3">
                    <label class="form-label">Your Address</label>
                    <input type="text" id="address" name="address" class="form-control form-control-sm validation" placeholder="Your Address">
                </div>

                <br>
                <button type="button" id="save_biodata" class="btn btn-danger btn-sm" style="float: right;">Save</button>
            </form>

        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {

        $('#save_biodata').on('click', function() {
            var name = $('#name').val();
            var address = $('#address').val();
            if (name == "") {
                alert("Nama harus terisi");
                return false;
            } else if (address == "") {
                alert("Alamat harus terisi");
                return false;
            } else {
                $.ajax({
                    url: "<?= base_url('C_biodata/insert_biodata') ?>",
                    type: "POST",
                    dataType: 'json',
                    data: {
                        name: name,
                        address: address,
                    },
                    success: function(data) {
                        console.log(data);
                        location.href = "<?= base_url('C_biodata') ?>";
                    }
                });
            }

        });
    });
</script>

<?= $this->endSection() ?>