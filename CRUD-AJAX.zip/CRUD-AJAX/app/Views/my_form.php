<?= $this->extend('template/ms_template.php') ?>
<?= $this->section('content') ?>

<div class="container">
    <div class="row">
        <div class="col-12 col-sm-8">
            <br>
            <h1 class="text-center">Sample Form</h1> <br>

            <a class="btn btn-primary btn-sm" href="<?= base_url('C_biodata') ?>">All_Data</a> <br><br>

            <form name="myForm" onsubmit="return validateForm()" method="post">
                Name: <input type="text" name="fname"> <br>
                Address: <input type="text" name="faddress">
                <input type="submit" value="Submit">
            </form>

        </div>
    </div>
</div>

<script>
    function validateForm() {
        var x = document.forms["myForm"]["fname", "faddress"].value;
        if (x == "") {
            alert("Harus terisi semua");
            return false;
        } else {
            alert("Oke");
        }
    }
</script>
<?= $this->endSection() ?>