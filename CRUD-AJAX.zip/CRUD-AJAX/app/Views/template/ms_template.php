<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>CRUD-AJAX-BAYU_SANTOSO</title>
    <meta name="description" content="Implementasi AJAX-JAVASCRIPT pada framework CodeIgniter 4">
    <meta name="author" content="Bayu Santoso">
    <meta name="robots" content="Implementasi AJAX-JAVASCRIPT pada framework CodeIgniter 4">
    <meta name="google-site-verification" content="Implementasi AJAX-JAVASCRIPT pada framework CodeIgniter 4">
    <link href="<?= base_url('bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">
    <script src="<?= base_url('bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('jquery.js') ?>"></script>

</head>

<body>
    <?= $this->renderSection('content') ?>
</body>


</html>