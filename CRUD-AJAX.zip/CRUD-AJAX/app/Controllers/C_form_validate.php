<?php

namespace App\Controllers;

use CodeIgniter\Controller;

use App\Models\M_biodata;

class C_form_validate extends Controller
{

    protected $M_biodata;

    function __construct()
    {
        $this->M_biodata = new M_biodata();
    }

    public function index()
    {
        return view('my_form');
    }
}
