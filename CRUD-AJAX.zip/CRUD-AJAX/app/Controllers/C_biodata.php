<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_biodata;

class C_biodata extends Controller
{

    protected $M_biodata;
    function __construct()
    {
        $this->M_biodata = new M_biodata();
    }

    public function index()
    {
        return view('biodata/read_biodata');
    }

    public function read_biodata()
    {
        $data = $this->M_biodata->findAll();
        echo json_encode($data);
    }

    public function view_create_biodata()
    {
        return view('biodata/create_biodata');
    }

    public function view_update_biodata($id)
    {
        $data['data_id'] = $this->M_biodata->select('*')->where('id_biodata', $id)->get()->getRowArray();
        return view('biodata/update_biodata', $data);
    }

    public function insert_biodata()
    {
        $add_name = $this->request->getPost('name');
        $add_address = $this->request->getPost('address');

        $add_Data = [
            'name' => $add_name,
            'address' => $add_address,
        ];
        $insert = $this->M_biodata->insert($add_Data);
        echo json_encode($add_Data);
    }

    public function update_biodata()
    {
        $id = $this->request->getPost('id');
        $add_name = $this->request->getPost('name');
        $add_address = $this->request->getPost('address');

        $add_Data = [
            'name' => $add_name,
            'address' => $add_address,
        ];
        $insert = $this->M_biodata->update($id, $add_Data);
        echo json_encode($add_Data);
    }

    public function delete_biodata()
    {
        $id = $this->request->getPost('id');
        $select_id = $this->M_biodata->where('id_biodata', $id)->delete();
        echo json_encode($select_id);
    }
}
